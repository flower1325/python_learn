#!-*- coding:utf-8 -*-
import sys
reload(sys)
sys.setdefaultencoding('utf-8')

#百度搜索输入的ID
soID='kw'
#百度一下的id
clickID='su'