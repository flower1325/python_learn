#!-*- coding:utf-8 -*-
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
'''系统所有的提示信息'''
inputName=u'请输入用户名'
